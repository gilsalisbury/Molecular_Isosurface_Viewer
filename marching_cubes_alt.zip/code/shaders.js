//###########################################################################
//###  Shader programs 
//###  orignal script from http://www.cs.unm.edu/~angel/WebGL/7E/Common/initShaders.js
//###########################################################################

function initShaders( gl )
{
    //  declare shader program objects
    var vertShdr;
    var fragShdr;

    var vertElem = $('#vertex-shader').html();  
    var fragElem = "\
        precision mediump float;    \
        varying vec4 fColor;        \
        void                        \
        main()                      \
        {                           \
            gl_FragColor = fColor;  \
        }                           \
    ";

    if ( !vertElem ) { 
        alert( "Unable to load vertex shader ");
        return -1;
    }
    else {
        // init shader objects and compile string of JS code
        vertShdr = gl.createShader( gl.VERTEX_SHADER );
        gl.shaderSource( vertShdr, vertElem );
        gl.compileShader( vertShdr );
        if ( !gl.getShaderParameter(vertShdr, gl.COMPILE_STATUS) ) {
            var msg = "Vertex shader failed to compile.  The error log is:"
            + "<pre>" + gl.getShaderInfoLog( vertShdr ) + "</pre>";
            alert( msg );
            return -1;
        }
    }

    if ( !fragElem ) { 
        alert( "Unable to load vertex shader ");
        return -1;
    }
    else {
        // init shader objects and compile string of JS code
        fragShdr = gl.createShader( gl.FRAGMENT_SHADER );
        gl.shaderSource( fragShdr, fragElem );
        gl.compileShader( fragShdr );
        if ( !gl.getShaderParameter(fragShdr, gl.COMPILE_STATUS) ) {
            var msg = "Fragment shader failed to compile.  The error log is:"
            + "<pre>" + gl.getShaderInfoLog( fragShdr ) + "</pre>";
            alert( msg );
            return -1;
        }
    }

    // init gl_program object and attach compile shaders
    var program = gl.createProgram();
    gl.attachShader( program, vertShdr );
    gl.attachShader( program, fragShdr );
    gl.linkProgram( program );
    
    if ( !gl.getProgramParameter(program, gl.LINK_STATUS) ) {
        var msg = "Shader program failed to link.  The error log is:"
            + "<pre>" + gl.getProgramInfoLog( program ) + "</pre>";
        alert( msg );
        return -1;
    }

    return program;
}


