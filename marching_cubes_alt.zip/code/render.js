// Donald Salisbury
// Program 1
// This program makes a static view of a Mandelbrot set surface from view angle (1,1,1)
var vertices = new Array();
var normals = new Array();
var vertex = new Array();
var coor = new Array();
var poly = new Array();
var poly_norms = new Array();
var norm = vec3.create();
var smooth = false;
var perspect = false;
var drag = false;
var drag_dir = [0,0];
var mousedown = [0,0];
var mouseup = [0,0];
var democube = [970, 1050, 1050]
var shark1 = {
    on: true,
    offset: vec3.fromValues(0,0,0)
    };
var shark2 = {
    on: true,
    offset: vec3.fromValues(0,0,0)
    };
var shark = shark1;

// Transformation Matrices
// Rotations
var scale = mat4.create();
scale = mat4.scale(scale, scale, [1/1700, 1/1700, 1/1700]);
var rotx = mat4.create();
rotx = mat4.rotateX(rotx, rotx, (3.14/180)*35.6);
var roty = mat4.create();
roty = mat4.rotateY(roty, roty, 3.14/3);
var rotz = mat4.create();
rotz = mat4.rotateZ(rotz, rotz, 3.14/4);
var rotation1 = mat4.create();
var rotation2 = mat4.create();
mat4.identity(rotation1);
mat4.identity(rotation2);
var rotation = rotation1;

// Projections
var trans = mat4.create();
trans = mat4.identity(trans);
var offset = vec3.fromValues(0,0, -2.2);
var projection = mat4.create();
projection = mat4.identity(projection); 
projection = mat4.perspective(projection, Math.PI/4, 1,  .1, 100);
var ortho = mat4.create();
ortho = mat4.ortho(ortho, -1, 1, -1, 1, -1, 1);


trans = mat4.translate(trans, trans, offset);
projection = mat4.multiply(projection, projection, trans);


// ModelView1
var modelView1 = mat4.create();
mat4.translate(modelView1, modelView1, [-1200, -900, 0]);
modelView1 = mat4.multiply(modelView1, scale, modelView1);
//modelView1 = mat4.multiply(modelView1, modelView1, rotx);
//modelView1 = mat4.multiply(modelView1, modelView1, roty);

// ModelView2
trans = mat4.identity(trans);
trans = mat4.translate(trans, trans, [0, .6, -2.2]);
var modelView2 = mat4.create();

modelView2 = mat4.multiply(modelView2, scale, modelView2);

//modelView2 = mat4.multiply(modelView2, modelView2, rotx);
modelView2 = mat4.multiply(modelView2, trans, modelView2);


//inverse transpose of modelView1
var modelViewT1 = mat4.create();
modelViewT1 = mat4.invert(modelViewT1, modelView1);
modelViewT1 = mat4.transpose(modelViewT1, modelViewT1);

//inverse transpose of modelView2
var modelViewT2 = mat4.create();
modelViewT2 = mat4.invert(modelViewT2, modelView2);
modelViewT2 = mat4.transpose(modelViewT2, modelViewT2);

var modelView = mat4.create();
var modelViewT = mat4.create();
var mv1 = mat4.create();
var mv2 = mat4.create();
var mvt = mat4.create();
var mvt2 = mat4.create();
modelView = modelView1;
modelViewT = modelViewT1;




var switchShader = function() {
    gl.bindFramebuffer(this.gl.FRAMEBUFFER, null);
    vertices.length = 0;
    //vertex.length = 0;
    gridArr.length = 0;
    vlist = {};
    nlist.length = 0;
    vertex_list.length = 0;
    for (v in vertex) {
        var i = Math.round(Math.random()*2 );
        vertex[v][i] += (-100*Math.random() + Math.random()*100) ;
    }
    alt_interp(vertex, gridArr);
    typedPositions = new Float32Array(vertices);
    gl.bufferData(gl.ARRAY_BUFFER, typedPositions, gl.STATIC_DRAW);
    render();

}


/*************************************
*  The initalization function for the*
*  canvas element and image drawings *
**************************************/
window.onload = function init() {
	canvas = document.getElementById( "gl-canvas" );
    canvas.addEventListener("click", getPosition, false);
    canvas.addEventListener("contextmenu", function(event) {
            event.preventDefault();
            democube[0] -= 100;
            var x = event.pageX;
            var y = event.clientY;
            //changePerspective(x,y);
            switchShader(gridArr);
            return false;
            }, false);
    
    var rect = canvas.getBoundingClientRect ();

	gl = canvas.getContext('experimental-webgl');
    if ( !gl ) { alert( "WebGL isn't available" ); }
    
	gl.enable(gl.DEPTH_TEST);
    //gl.depthFunc(gl.GREATER);
    //gl.clearDepth(0.0);



    //var data = process_data_files();
    typedPositions = new Float32Array(vertices);
    

    // set the size of the gl object space
    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 0, 0, 1, 1.0 );
    

    // variables for offscreen frame buffer
    var fb = gl.createFramebuffer();
    var pixelData = new Uint8Array(canvas.width * canvas.height * 4);
    var rttTexture = gl.createTexture();
    var renderbuffer = gl.createRenderbuffer();   


    var init_offscreen_framebuff = function() {
        gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
        gl.bindTexture(gl.TEXTURE_2D, rttTexture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, canvas.width, canvas.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        gl.bindRenderbuffer(gl.RENDERBUFFER, renderbuffer);
        gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, canvas.width, canvas.height);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, rttTexture, 0);
        gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, renderbuffer);
        console.log(gl);
    }


    //init_offscreen_framebuff();
    //  Load shaders and initialize attribute buffers
    var program = initShaders( gl );
    gl.useProgram( program );
    

    //  bind transformation matrices
    mat_modelView = gl.getUniformLocation(program, "modelView");
    mat_modelViewT = gl.getUniformLocation(program, "modelViewT");
    mat_projection = gl.getUniformLocation(program, "projection");


    // populate transformation matrices
    gl.uniformMatrix4fv(mat_modelView, false, modelView);
    gl.uniformMatrix4fv(mat_modelViewT, false, modelViewT);
    gl.uniformMatrix4fv(mat_projection, false, projection);
    

    // buffer functions
    var vBuffer1 = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer1);
    gl.bufferData(gl.ARRAY_BUFFER, typedPositions, gl.STATIC_DRAW);
    
    
    // declare vertex position pointer
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.enableVertexAttribArray(vPosition);
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 24, 0);


    var vNormal = gl.getAttribLocation( program, "vNormal");
    gl.enableVertexAttribArray(vNormal);
    gl.vertexAttribPointer(vNormal, 3, gl.FLOAT, false, 24, 12);
    
    //initGrid();
    vertex.push(vec3.fromValues(1000+Math.random()*300, (democube[1]+Math.random()*100), democube[2]+Math.random()*100));
    vertex.push(vec3.fromValues(1000+Math.random()*300, (democube[1]+Math.random()*100), democube[2]+Math.random()*100));
    vertex.push(vec3.fromValues(democube[0]+Math.random()*100, democube[1]+Math.random()*100, democube[2]+Math.random()*100));
    vertex.push(vec3.fromValues(1000+Math.random()*400, (democube[1]+Math.random()*100), democube[2]+Math.random()*100));
    vertex.push(vec3.fromValues(1000+Math.random()*300, (democube[1]+Math.random()*100), democube[2]+Math.random()*100));
    vertex.push(vec3.fromValues(1000+Math.random()*100, (democube[1]+Math.random()*100), democube[2]+Math.random()*100));
    var loop = setInterval(function() {switchShader();}, .1);

    //switchShader();

    var GetColourMapColour = function (x, y) {
        if (x >= canvas.width || y >= canvas.height || x < 0 || y < 0) 
            throw "Invalid colour map pixel address";
        if (!pixelData) throw "Colour map not captured.";
        // 4 components per colour, and y is inverted
        var firstAddress = (y) * canvas.width * 4 + x * 4;
        
        return [pixelData[firstAddress],
                pixelData[firstAddress + 1],
                pixelData[firstAddress + 2]];
}

    function getPosition(event) {
        
        democube[0] += 100;
        switchShader();
        
    } 

    var changePerspective = function(x,y) {
        x -= rect.left;
        y -= rect.bottom;
        y = -y;
        x = Math.round(x);
        y = Math.round(y);
        gl.readPixels(0, 0, canvas.width, canvas.height, gl.RGBA, gl.UNSIGNED_BYTE, pixelData);
        var color = GetColourMapColour(x,y);
        if (color[0] !=0 | color[1] != 0 | color[2] != 255 ) {
            if(perspect){
                gl.enable(gl.DEPTH_TEST);
                gl.uniformMatrix4fv(mat_projection, false, projection);
                perspect = false;
            }
            else{
                gl.uniformMatrix4fv(mat_projection, false, ortho);
                perspect = true;
            }
            switchShader();
        }
        var vertexBufferIndex = color[0] * 65536 + color[1] * 256 + color[2];
        
        return false;
    }

    $(canvas).mousedown( function(event) {
        //console.log(event);
        mousedown = [event.pageX, event.pageY];
        //console.log(rect);
        drag = true;
        $(document).mousemove( function(e) {
            if(drag){
                if(shark1.on == true) {
                    rotation = rotation1;
                    modelView = modelView1;
                    modelViewT = modelViewT1;
                }else{
                    rotation = rotation2;
                    modelView = modelView2;
                    modelViewT = modelViewT2;
                }
                var angle = Math.PI/300;
                trans = mat4.identity(trans);
                var axis = vec3.fromValues( (mousedown[0] - e.pageX),  (mousedown[1] - e.pageY), 0);
                
               
                axis = vec3.normalize(axis, axis);
                
                
                
                var deltaX = axis[0];
                //console.log((2*Math.PI*(deltaX / 1)/360));
                var newRotationMatrix = mat4.create();
                mat4.identity(newRotationMatrix);
                mat4.rotate(newRotationMatrix, newRotationMatrix, (14*Math.PI*(deltaX / 1)/360), [0,1,0]);

                var deltaY = axis[1];
                mat4.rotate(newRotationMatrix, newRotationMatrix, (14*Math.PI*(deltaY / 1)/360), [1,0,0]);
                mat4.multiply(rotation, rotation, newRotationMatrix);
                
                var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
                modelView = mat4.translate(modelView, modelView,  offset);
                modelView = mat4.multiply(modelView, modelView, newRotationMatrix);
                modelView = mat4.translate(modelView, modelView, shark.offset);
                shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
                

                modelViewT = mat4.clone(modelViewT);
                modelViewT = mat4.invert(modelViewT, modelView);
                modelViewT = mat4.transpose(modelViewT, modelViewT);

                mousedown[0] = e.pageX; mousedown[1] = e.pageY;

                if(shark1.on == true) {
            
                    modelView1 = modelView;
                    modelViewT1 = modelViewT;
                    rotation1 = rotation;
                }else{
            
                    modelView2 = modelView;
                    modelViewT2 = modelViewT;
                    rotation1 = rotation;
                }
                render();
            }
        });
    });

    $(document).mouseup( function(event) {
                drag = false;
            });

    $(document).keydown( function(event) {
        
        
        if(shark1.on == true) {

            modelView = modelView1;
            modelViewT = modelViewT1;
        }else{
            
            modelView = modelView2;
            modelViewT = modelViewT2;
        }
        if (String.fromCharCode(event.keyCode)=="F") {
            if(shark1.on) {
                shark1.on = false;
                shark2.on = true;
                shark = shark2;
            }else{
                shark1.on = true;
                shark2.on = false;
                shark = shark1;
            } 
            return;  
        }
        if (event.keyCode==32) {
            
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.rotateX(modelView, modelView, -Math.PI/7);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
            event.preventDefault();
        }
        if (event.keyCode==38) {
            
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.rotateZ(modelView, modelView, -Math.PI/10);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
            event.preventDefault();
        }
        if (event.keyCode==40) {
            
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.rotateZ(modelView, modelView, Math.PI/10);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
            event.preventDefault();
        }
        if (event.keyCode==37) {
            
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.rotateY(modelView, modelView, Math.PI/10);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
            event.preventDefault();
        }
        if (event.keyCode==39) {
            
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.rotateY(modelView, modelView, -Math.PI/10);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
            event.preventDefault();
        }
        if (String.fromCharCode(event.keyCode)=="H") {
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.scale(modelView, modelView, [4/5, 1, 1]);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
          
        }
        if (String.fromCharCode(event.keyCode)=="K") {
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.scale(modelView, modelView, [5/4, 1, 1]);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
          
        }
        if (String.fromCharCode(event.keyCode)=="U") {
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.scale(modelView, modelView, [1, 4/5, 1]);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
          
        }
        if (String.fromCharCode(event.keyCode)=="J") {
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.scale(modelView, modelView, [1, 5/4, 1]);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
          
        }

        if (String.fromCharCode(event.keyCode)=="M") {
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.scale(modelView, modelView, [1, 1, 4/5]);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
          
        }
        if (String.fromCharCode(event.keyCode)=="N") {
            
            var offset = [-shark.offset[0], -shark.offset[1],-shark.offset[2]];
            modelView = mat4.translate(modelView, modelView, offset);
            modelView = mat4.scale(modelView, modelView, [1, 1, 5/4]);
            modelView = mat4.translate(modelView, modelView, shark.offset);
            shark.offset = vec3.transformMat4(shark.offset, shark.offset, modelView);
          
        }
        
        
        if (String.fromCharCode(event.keyCode)=="A") {
  
            trans = mat4.identity(trans);
            modelView = mat4.translate(modelView, modelView, [0, 0, 8]);
            shark.offset[2] += 4;
        }
        if (String.fromCharCode(event.keyCode)=="D") {
            
            trans = mat4.identity(trans);
            modelView = mat4.translate(modelView, modelView, [0, 0, -8]);
            shark.offset[2] -= 4;
        }
        if (String.fromCharCode(event.keyCode)=="S") {
           
            trans = mat4.identity(trans);
            modelView = mat4.translate(modelView, modelView, [8, 0, 0]);
            shark.offset[0] += 4;
        }
        if (String.fromCharCode(event.keyCode)=="W") {
           
            trans = mat4.identity(trans);
            modelView = mat4.translate(modelView, modelView, [-8, 0, 0]);
            shark.offset[0] -= 4;
        }
        if (String.fromCharCode(event.keyCode)=="Z") {
            
            trans = mat4.identity(trans);
            modelView = mat4.translate(modelView, modelView, [0, 8, 0]);
            shark.offset[1] += 4;
        }
        if (String.fromCharCode(event.keyCode)=="X") {
            
            trans = mat4.identity(trans);
            modelView = mat4.translate(modelView, modelView, [0, -8, 0]);
            shark.offset[1] -= 4;
        }

        
        modelViewT = mat4.identity(modelViewT);
        modelViewT = mat4.invert(modelViewT, modelView);
        modelViewT = mat4.transpose(modelViewT, modelViewT);

        if(shark1.on == true) {
            
            modelView1 = modelView;
            modelViewT1 = modelViewT;
        }else{
            
            modelView2 = modelView;
            modelViewT2 = modelViewT;
        }

        render();
    });
}

function render() {
    gl.bindFramebuffer(this.gl.FRAMEBUFFER, null);
    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT );
    
    gl.uniformMatrix4fv(mat_modelView, false, modelView1);
    gl.uniformMatrix4fv(mat_modelViewT, false, modelViewT1);
    
    for(var i=0;i<(vertices.length/6-3); i+=3){
        gl.drawArrays( gl.TRIANGLES, i, 3);
    }
    
}
